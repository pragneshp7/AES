// ==============================================================
// File generated on Thu Apr 28 21:19:52 -0500 2022
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaes_mix_columns.h"

extern XAes_mix_columns_Config XAes_mix_columns_ConfigTable[];

XAes_mix_columns_Config *XAes_mix_columns_LookupConfig(u16 DeviceId) {
	XAes_mix_columns_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAES_MIX_COLUMNS_NUM_INSTANCES; Index++) {
		if (XAes_mix_columns_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAes_mix_columns_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAes_mix_columns_Initialize(XAes_mix_columns *InstancePtr, u16 DeviceId) {
	XAes_mix_columns_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAes_mix_columns_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAes_mix_columns_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

