// ==============================================================
// File generated on Thu Apr 28 21:19:52 -0500 2022
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaes_mix_columns.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAes_mix_columns_CfgInitialize(XAes_mix_columns *InstancePtr, XAes_mix_columns_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAes_mix_columns_Start(XAes_mix_columns *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL) & 0x80;
    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAes_mix_columns_IsDone(XAes_mix_columns *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAes_mix_columns_IsIdle(XAes_mix_columns *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAes_mix_columns_IsReady(XAes_mix_columns *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAes_mix_columns_EnableAutoRestart(XAes_mix_columns *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XAes_mix_columns_DisableAutoRestart(XAes_mix_columns *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_AP_CTRL, 0);
}

u32 XAes_mix_columns_Get_state_BaseAddress(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE);
}

u32 XAes_mix_columns_Get_state_HighAddress(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH);
}

u32 XAes_mix_columns_Get_state_TotalBytes(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + 1);
}

u32 XAes_mix_columns_Get_state_BitWidth(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_MIX_COLUMNS_AXILITES_WIDTH_STATE;
}

u32 XAes_mix_columns_Get_state_Depth(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_MIX_COLUMNS_AXILITES_DEPTH_STATE;
}

u32 XAes_mix_columns_Write_state_Words(XAes_mix_columns *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XAes_mix_columns_Read_state_Words(XAes_mix_columns *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + (offset + i)*4);
    }
    return length;
}

u32 XAes_mix_columns_Write_state_Bytes(XAes_mix_columns *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XAes_mix_columns_Read_state_Bytes(XAes_mix_columns *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_BASE + offset + i);
    }
    return length;
}

u32 XAes_mix_columns_Get_state_out_BaseAddress(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE);
}

u32 XAes_mix_columns_Get_state_out_HighAddress(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH);
}

u32 XAes_mix_columns_Get_state_out_TotalBytes(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + 1);
}

u32 XAes_mix_columns_Get_state_out_BitWidth(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_MIX_COLUMNS_AXILITES_WIDTH_STATE_OUT;
}

u32 XAes_mix_columns_Get_state_out_Depth(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_MIX_COLUMNS_AXILITES_DEPTH_STATE_OUT;
}

u32 XAes_mix_columns_Write_state_out_Words(XAes_mix_columns *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XAes_mix_columns_Read_state_out_Words(XAes_mix_columns *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + (offset + i)*4);
    }
    return length;
}

u32 XAes_mix_columns_Write_state_out_Bytes(XAes_mix_columns *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XAes_mix_columns_Read_state_out_Bytes(XAes_mix_columns *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_HIGH - XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Axilites_BaseAddress + XAES_MIX_COLUMNS_AXILITES_ADDR_STATE_OUT_BASE + offset + i);
    }
    return length;
}

void XAes_mix_columns_InterruptGlobalEnable(XAes_mix_columns *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_GIE, 1);
}

void XAes_mix_columns_InterruptGlobalDisable(XAes_mix_columns *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_GIE, 0);
}

void XAes_mix_columns_InterruptEnable(XAes_mix_columns *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_IER);
    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_IER, Register | Mask);
}

void XAes_mix_columns_InterruptDisable(XAes_mix_columns *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_IER);
    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_IER, Register & (~Mask));
}

void XAes_mix_columns_InterruptClear(XAes_mix_columns *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_mix_columns_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_ISR, Mask);
}

u32 XAes_mix_columns_InterruptGetEnabled(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_IER);
}

u32 XAes_mix_columns_InterruptGetStatus(XAes_mix_columns *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAes_mix_columns_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_MIX_COLUMNS_AXILITES_ADDR_ISR);
}

